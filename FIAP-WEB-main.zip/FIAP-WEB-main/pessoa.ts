export class Pessoa {
    name: string;
    age: number;
  
    constructor(nome: string, idade: number) {
      this.name = nome;
      this.age = idade;
    }
}