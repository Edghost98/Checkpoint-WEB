export class Cliente {
  constructor(public nome: string, public email: string) { }
}
