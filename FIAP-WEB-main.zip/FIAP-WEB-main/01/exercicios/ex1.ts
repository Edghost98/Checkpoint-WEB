let my_name: string = "Juttahir Moraes";
let age: number = 30;
let alive: boolean = true;
let skills: string[] = ["C#", 'Python', 'HTML/CSS/JS', 'Angular', 'SQL']

console.log(`Nome: ${my_name}`);
console.log(`Idade: ${age}`);
console.log(`Ativo: ${alive}`);
console.log(`Habilidades: ${skills}`);

