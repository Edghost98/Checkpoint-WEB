let nome: string = "Juttahir Moraes";
let idade: number = 30;
let tupla: [string, number] = ["Juttahir Moraes", 30];
console.log("Meu nome é " + nome + " e tenho " + idade + " anos")
console.log(tupla)
